# -*- coding: utf8 -*-


def suma_total(monto=0):
    """ Calcula la suma total """
    calculo_suma = 20
    calculo_suma += monto
    return calculo_suma
