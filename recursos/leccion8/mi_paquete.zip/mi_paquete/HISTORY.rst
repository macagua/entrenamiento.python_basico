=======
History
=======

0.0.1 (2025-04-05)
------------------

* First release on PyPI.
