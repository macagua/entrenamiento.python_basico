"""Top-level package for Mi Paquete."""

__author__ = """Leonardo J. Caballero G."""
__email__ = 'leonardocaballero@gmail.com'
__version__ = '0.0.1'
