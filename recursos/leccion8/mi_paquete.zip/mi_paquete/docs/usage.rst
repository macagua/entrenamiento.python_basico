=====
Usage
=====

To use Mi Paquete in a project::

    import mi_paquete
