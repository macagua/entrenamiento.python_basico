Installation
============

::

    cookiecutter -c 301eceaee466f6031b93c917cd03d6b3aced3440 https://github.com/audreyfeldroy/cookiecutter-pypackage
