==========
Mi Paquete
==========


.. image:: https://img.shields.io/pypi/v/mi_paquete.svg
        :target: https://pypi.python.org/pypi/mi_paquete

.. image:: https://img.shields.io/travis/macagua/mi_paquete.svg
        :target: https://travis-ci.com/macagua/mi_paquete

.. image:: https://readthedocs.org/projects/mi-paquete/badge/?version=latest
        :target: https://mi-paquete.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status


Project Description
===================

Mi primer paquete Python


* Free software: MIT license
* Documentation: https://mi-paquete.readthedocs.io.

Installation
------------

You can see how create this `audreyr/cookiecutter-pypackage`_ template checking
the ``INSTALL.rst`` file in the root of this repository.

Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
