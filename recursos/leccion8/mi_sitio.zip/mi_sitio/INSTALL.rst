Installation
============

::

    pip3 "install Django==5.2"
